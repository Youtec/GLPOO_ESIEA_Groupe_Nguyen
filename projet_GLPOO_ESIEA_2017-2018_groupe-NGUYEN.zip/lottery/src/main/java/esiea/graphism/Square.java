package esiea.graphism;

import java.awt.*;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;
import java.util.Random;

import javax.imageio.*;

import javax.swing.JFrame;

import esiea.lottery.dao.CsvLotteryDao;
import esiea.lottery.dao.LotteryDao;
import esiea.lottery.domain.Lottery;

public class Square extends JFrame {
	
	private List<Lottery> tirages;
	// private int frameWidth = 1400, frameHeight = 1000; 
	private int frameWidth = 1400, frameHeight = 1000;
	Affichage theAffichage = new Affichage();
	VariablesBoules theRandom = new VariablesBoules();
	public int frameNbr = 0;
	public String filepath;


	public Square() throws Exception {
		Random r = new Random();
		int i = 1 + r.nextInt(142 - 1);
	final String fileName = "src/main/resources/my_euromillions.csv";
		final File file = new File(fileName);
		final LotteryDao dao = new CsvLotteryDao();
		dao.init(file);
		tirages = dao.findAllTirage();
		
		setBounds(100, 100, frameWidth, frameHeight); //window settings
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(false);
	}
	
	int numBoule;
	int numBoule3;
	int numBoule4;
	int numBoule5;
	int numBoule6;
	int numBoule7;
	
	public void getPrint(int choix, Object[][] data) {
		BufferedImage bi = new BufferedImage(frameWidth, frameHeight, BufferedImage.TYPE_INT_ARGB); 
		Graphics g = bi.createGraphics();
		this.paint(choix, data,g);  //this == JComponent
		g.dispose();
		BufferedImage b = scaleImage(bi, 650, 580,Color.BLACK);
		filepath = "PicBin/test"+frameNbr+".png";
		try{ImageIO.write(b,"png",new File(filepath));}catch (Exception e) {}
		frameNbr++;
	}
	
	public void paint (int choix, Object[][]data, Graphics g) {
		
		Color colorBackground = new Color(0,128,255); //Couleur Background
		g.setColor(colorBackground);
		g.fillRect(0, 0, frameWidth, frameHeight);
		
		for(int i = 0; i<choix ; i++) {
			numBoule = (int) data[i][6];
			numBoule3 = (int) data[i][0];
			numBoule4 = (int) data[i][1];
			numBoule5 = (int) data[i][2];
			numBoule6 = (int) data[i][3];
			numBoule7 = (int) data[i][4];
			/*int numBoule = boule1;
			int numBoule3 = boule2;
			int numBoule4 = boule3;
			int numBoule5 = boule4;
			int numBoule6 = boule5;
			int numBoule7 = etoile1;*/
			switch((int) data[i][5]) {
			case 1:
				getDot(g);
				break;
			case 2:
				getLine(g);
				break;
			case 3:
				getTriangle(g);
				break;
			case 4:
				getSquare(g);
				break;
			case 5:
				getPentagone(g);
				break;
			case 6:
				getHexagone(g);
				break;
			case 7:
				getFleche(g);
				break;
			case 8:
				getPolygonObject(g);
				break;
			case 9:
				getFlecheCourbe(g);
				break;
			case 10:
				getFlecheDouble(g);
				break;
			case 11:
				getRectangleFleche(g);
				break;
			case 12:
				getCroix(g);
				break;
				}
			}
		}
	public void getSquare(Graphics g) {
		numBoule4 = numBoule4*4;
		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		g.setColor(theBlue);
		g.fillRect(0+numBoule6, 100+numBoule7, 150+numBoule4, 150 +numBoule5);
		g.setColor(myBlue);
		g.fillRect(15+numBoule6, 115+numBoule7, 125+numBoule4, 125+numBoule5);
	}
	
	public void getTriangle(Graphics g) {

		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		int [] x = {0+numBoule6,300+numBoule6,600+numBoule6};//triangle
		int [] y = {400+numBoule7,0+numBoule7,400+numBoule7};//triangle
		
		int [] x1 = {35+numBoule6,300+numBoule6,565+numBoule6};//triangle
		int [] y1 = {385+numBoule7,25+numBoule7,385+numBoule7};//triangle
		

		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		g.setColor(theBlue);
		theRandom.convArrayAbsc(x,y,3,numBoule4);
		theRandom.convArrayAbsc(x1,y1,3,numBoule4);
		g.fillPolygon(x,y,3);
		g.setColor(myBlue);
		g.fillPolygon(x1,y1,3);
	}
	
	public void getRectangleFleche(Graphics g) {

		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		int [] x = {100-100+numBoule6,100-100+numBoule6,300-100+numBoule6,300-100+numBoule6,500-100+numBoule6,500-100+numBoule6,700-100+numBoule6,500-100+numBoule6,500-100+numBoule6,300-100+numBoule6,300-100+numBoule6};
		int [] y = {600-200+numBoule7,200-200+numBoule7,200-200+numBoule7,300-200+numBoule7,300-200+numBoule7,200-200+numBoule7,400-200+numBoule7,600-200+numBoule7,500-200+numBoule7,500-200+numBoule7,600-200+numBoule7};
		
		int [] x1 = {115-100+numBoule6,115-100+numBoule6,285-100+numBoule6,285-100+numBoule6,515-100+numBoule6,515-100+numBoule6,685-100+numBoule6,515-100+numBoule6,515-100+numBoule6,285-100+numBoule6,285-100+numBoule6};
		int [] y1 = {585-200+numBoule7,215-200+numBoule7,215-200+numBoule7,315-200+numBoule7,315-200+numBoule7,225-200+numBoule7,400-200+numBoule7,575-200+numBoule7,485-200+numBoule7,485-200+numBoule7,585-200+numBoule7};	

		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		g.setColor(theBlue);
		theRandom.convArrayAbsc(x,y,11,numBoule4);
		theRandom.convArrayAbsc(x1,y1,11,numBoule4);
		g.fillPolygon(x,y,11);
		g.setColor(myBlue);
		g.fillPolygon(x1,y1,11);
	}
	public void getFleche(Graphics g) {

		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		int [] x = {100-100+numBoule6,100-100+numBoule6,500-100+numBoule6,500-100+numBoule6,800-100+numBoule6,500-100+numBoule6,500-100+numBoule6};
		int [] y = {600-300+numBoule7,400-300+numBoule7,400-300+numBoule7,300-300+numBoule7,500-300+numBoule7,700-300+numBoule7,600-300+numBoule7};
		
		int [] x1 = {115-100+numBoule6,115-100+numBoule6,515-100+numBoule6,515-100+numBoule6,785-100+numBoule6,515-100+numBoule6,515-100+numBoule6};
		int [] y1 = {585-300+numBoule7,415-300+numBoule7,415-300+numBoule7,325-300+numBoule7,500-300+numBoule7,675-300+numBoule7,585-300+numBoule7};

		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		g.setColor(theBlue);
		theRandom.convArrayAbsc(x,y,7,numBoule4);
		theRandom.convArrayAbsc(x1,y1,7,numBoule4);
		g.fillPolygon(x,y,7);
		g.setColor(myBlue);
		g.fillPolygon(x1,y1,7);
	}
	
	public void getCroix(Graphics g) {

		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		int [] x = {100-100+numBoule6,100-100+numBoule6,200-100+numBoule6,200-100+numBoule6,400-100+numBoule6,400-100+numBoule6,500-100+numBoule6,500-100+numBoule6,400-100+numBoule6,400-100+numBoule6,200-100+numBoule6,200-100+numBoule6};
		int [] y = {400-100+numBoule7,200-100+numBoule7,200-100+numBoule7,100-100+numBoule7,100-100+numBoule7,200-100+numBoule7,200-100+numBoule7,400-100+numBoule7,400-100+numBoule7,500-100+numBoule7,500-100+numBoule7,400-100+numBoule7};
		
		int [] x1 = {115-100+numBoule6,115-100+numBoule6,215-100+numBoule6,215-100+numBoule6,385-100+numBoule6,385-100+numBoule6,485-100+numBoule6,485-100+numBoule6,385-100+numBoule6,385-100+numBoule6,215-100+numBoule6,215-100+numBoule6};
		int [] y1 = {385-100+numBoule7,215-100+numBoule7,215-100+numBoule7,115-100+numBoule7,115-100+numBoule7,215-100+numBoule7,215-100+numBoule7,385-100+numBoule7,385-100+numBoule7,485-100+numBoule7,485-100+numBoule7,385-100+numBoule7};
		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		g.setColor(theBlue);
		theRandom.convArrayAbsc(x,y,12,numBoule4);
		theRandom.convArrayAbsc(x1,y1,12,numBoule4);
		g.fillPolygon(x,y,12);
		g.setColor(myBlue);
		g.fillPolygon(x1,y1,12);
	}
	
	public void getDot(Graphics g) {

		numBoule4 = numBoule4*4;
		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		g.setColor(theBlue);
		g.fillOval(0+numBoule6, 100+numBoule7, 150+numBoule4, 150 +numBoule5);
		g.setColor(myBlue);
		g.fillOval(15+numBoule6, 115+numBoule7, 125+numBoule4, 125+numBoule5);
	}
	
	public void getPolygonObject(Graphics g) {

		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		int [] x = {400-100+numBoule6,300-100+numBoule6,100-100+numBoule6,300-100+numBoule6,400-100+numBoule6,500-100+numBoule6,700-100+numBoule6,500-100+numBoule6};
		int [] y = {700-100+numBoule7,500-100+numBoule7,400-100+numBoule7,300-100+numBoule7,100-100+numBoule7,300-100+numBoule7,400-100+numBoule7,500-100+numBoule7};
		
		int [] x1 = {400-100+numBoule6,300-100+numBoule6,150-100+numBoule6,300-100+numBoule6,400-100+numBoule6,500-100+numBoule6,650-100+numBoule6,500-100+numBoule6};
		int [] y1 = {650-100+numBoule7,500-100+numBoule7,400-100+numBoule7,300-100+numBoule7,150-100+numBoule7,300-100+numBoule7,400-100+numBoule7,500-100+numBoule7};
		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		g.setColor(theBlue);
		theRandom.convArrayAbsc(x,y,8,numBoule4);
		theRandom.convArrayAbsc(x1,y1,8,numBoule4);
		g.fillPolygon(x,y,8);
		g.setColor(myBlue);
		g.fillPolygon(x1,y1,8);
	}
	
	public void getFlecheCourbe(Graphics g) {

		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		int [] x = {200-200+numBoule6,200-200+numBoule6,600-200+numBoule6,600-200+numBoule6,700-200+numBoule6,500-200+numBoule6,300-200+numBoule6,400-200+numBoule6,400-200+numBoule6};
		int [] y = {400-200+numBoule7,200-200+numBoule7,200-200+numBoule7,600-200+numBoule7,600-200+numBoule7,800-200+numBoule7,600-200+numBoule7,600-200+numBoule7,400-200+numBoule7};
		
		int [] x1 = {215-200+numBoule6,215-200+numBoule6,585-200+numBoule6,585-200+numBoule6,675-200+numBoule6,500-200+numBoule6,325-200+numBoule6,415-200+numBoule6,415-200+numBoule6};
		int [] y1 = {385-200+numBoule7,215-200+numBoule7,215-200+numBoule7,615-200+numBoule7,615-200+numBoule7,785-200+numBoule7,615-200+numBoule7,615-200+numBoule7,385-200+numBoule7};
		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		g.setColor(theBlue);
		theRandom.convArrayAbsc(x,y,9,numBoule4);
		theRandom.convArrayAbsc(x1,y1,9,numBoule4);
		g.fillPolygon(x,y,9);
		g.setColor(myBlue);
		g.fillPolygon(x1,y1,9);
	}
	public void getHexagone(Graphics g) {

		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		int [] x = {200-100+numBoule6,100-100+numBoule6,200-100+numBoule6,400-100+numBoule6,500-100+numBoule6,400-100+numBoule6};
		int [] y = {600-200+numBoule7,400-200+numBoule7,200-200+numBoule7,200-200+numBoule7,400-200+numBoule7,600-200+numBoule7};
		
		int [] x1 = {215-100+numBoule6,125-100+numBoule6,215-100+numBoule6,385-100+numBoule6,475-100+numBoule6,385-100+numBoule6};
		int [] y1 = {585-200+numBoule7,400-200+numBoule7,215-200+numBoule7,215-200+numBoule7,400-200+numBoule7,585-200+numBoule7};
		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		g.setColor(theBlue);
		theRandom.convArrayAbsc(x,y,6,numBoule4);
		theRandom.convArrayAbsc(x1,y1,6,numBoule4);
		g.fillPolygon(x,y,6);
		g.setColor(myBlue);
		g.fillPolygon(x1,y1,6);
	}
	
	public void getPentagone(Graphics g) {

		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		int [] x = {200-100+numBoule6,100-100+numBoule6,300-100+numBoule6,500-100+numBoule6,400-100+numBoule6};
		int [] y = {600-200+numBoule7,400-200+numBoule7,200-200+numBoule7,400-200+numBoule7,600-200+numBoule7};
		
		int [] x1 = {215-100+numBoule6,125-100+numBoule6,300-100+numBoule6,475-100+numBoule6,385-100+numBoule6};
		int [] y1 = {585-200+numBoule7,400-200+numBoule7,225-200+numBoule7,400-200+numBoule7,585-200+numBoule7};
		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		g.setColor(theBlue);
		theRandom.convArrayAbsc(x,y,5,numBoule4);
		theRandom.convArrayAbsc(x1,y1,5,numBoule4);
		g.fillPolygon(x,y,5);
		g.setColor(myBlue);
		g.fillPolygon(x1,y1,5);
	}
	public void getFlecheDouble(Graphics g) {

		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		int [] x = {300-100+numBoule6,100-100+numBoule6,300-100+numBoule6,300-100+numBoule6,500-100+numBoule6,500-100+numBoule6,700-100+numBoule6,500-100+numBoule6,500-100+numBoule6,300-100+numBoule6};
		int [] y = {500-100+numBoule7,300-100+numBoule7,100-100+numBoule7,200-100+numBoule7,200-100+numBoule7,100-100+numBoule7,300-100+numBoule7,500-100+numBoule7,400-100+numBoule7,400-100+numBoule7};
		int [] x1 = {285-100+numBoule6,125-100+numBoule6,285-100+numBoule6,285-100+numBoule6,515-100+numBoule6,515-100+numBoule6,685-100+numBoule6,515-100+numBoule6,515-100+numBoule6,285-100+numBoule6};
		int [] y1 = {475-100+numBoule7,300-100+numBoule7,125-100+numBoule7,215-100+numBoule7,215-100+numBoule7,125-100+numBoule7,300-100+numBoule7,475-100+numBoule7,385-100+numBoule7,385-100+numBoule7};
		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		g.setColor(theBlue);
		theRandom.convArrayAbsc(x,y,10,numBoule4);
		theRandom.convArrayAbsc(x1,y1,10,numBoule4);
		g.fillPolygon(x,y,10);
		g.setColor(myBlue);
		g.fillPolygon(x1,y1,10);
	}
	public void getLine(Graphics g) {

		numBoule4 = numBoule4*4;
		numBoule5 = numBoule5*4;
		numBoule6 = numBoule6*20;
		numBoule7 = numBoule7*10;
		
		Color myBlue = theRandom.getColor(numBoule);
		Color theBlue = new Color(0,0,5*numBoule3);
		
		JFrame jf = new JFrame("Demo");
	    Container cp = jf.getContentPane();
	    
		g.setColor(theBlue);    		
	    Graphics2D g2 = (Graphics2D) g;
	    g2.setStroke(new BasicStroke(50));
	    g2.draw(new Line2D.Float(numBoule6*2, numBoule7*3, numBoule4*4, numBoule5*2));
	}
	
	public BufferedImage scaleImage(BufferedImage img, int width, int height,
	        Color background) {
	    int imgWidth = img.getWidth();
	    int imgHeight = img.getHeight();
	    if (imgWidth*height < imgHeight*width) {
	        width = imgWidth*height/imgHeight;
	    } else {
	        height = imgHeight*width/imgWidth;
	    }
	    BufferedImage newImage = new BufferedImage(width, height,
	            BufferedImage.TYPE_INT_RGB);
	    Graphics2D g = newImage.createGraphics();
	    try {
	        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
	                RenderingHints.VALUE_INTERPOLATION_BICUBIC);
	        g.setBackground(background);
	        g.clearRect(0, 0, width, height);
	        g.drawImage(img, 0, 0, width, height, null);
	    } finally {
	        g.dispose();
	    }
	    return newImage;
	}
	
}
