package esiea.graphism;


public class Affichage {
	
	VariablesBoules theRandom = new VariablesBoules();
	
	public int getBoule(int numBoule){
		switch (numBoule){
		case 1:
			return theRandom.EtoileRandom();
		case 2:
			return theRandom.EtoileRandom();
		case 3:
			return theRandom.GenRandom();
		case 4:
			return theRandom.GenRandom();
		case 5:
			return theRandom.GenRandom();
		case 6:
			return theRandom.GenRandom();
		case 7:
			return theRandom.GenRandom();
		}
		return numBoule;
	}
	
	public void theAffichage() throws Exception{
		new Square();
	}
		
}
