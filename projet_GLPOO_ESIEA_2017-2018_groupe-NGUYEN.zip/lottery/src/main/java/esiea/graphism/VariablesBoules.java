package esiea.graphism;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.awt.*;

public class VariablesBoules {

	public int GenRandom() {
		Random r = new Random();
		int valeur = 1 + r.nextInt(50 - 1);
		return valeur;
	}
	
	public int EtoileRandom() {
		Random r = new Random();
		int valeur = 1 + r.nextInt(12 - 1);
		return valeur;
	}
	
	
	public int RandomX() {
		int randomNum = ThreadLocalRandom.current().nextInt(1, 50 + 1);
		return randomNum;
	}
	
	//Fonction pour agrandir la taille de la forme en longueur
	public void convArrayAbsc(int [] x, int [] y, int cote, int numboule) {
		double res;
		int theRes;
		for(int i = 0; i < cote; i++) {
			res = numboule*0.04*x[i];
			theRes = (int)res; 
			x[i] = theRes; 
		}
	}
	
	//Fonction pour agrandir la taille de la forme en hauteur
	public void convArrayOrd(int [] x, int [] y, int cote, int numboule) {
		double res;
		int theRes;
		for(int i = 0; i < cote; i++) {
			res = numboule*0.04*y[i];
			theRes = (int)res; 
			y[i] = theRes; 
		}
	}
	
	public Color getColor(int numBoule) {
		Color colorPurple = new Color(102,0,51);
		Color darkBlue= new Color(0,51,102);
		Color theOrange= new Color(204,102,10);
		
		if(numBoule == 1) {
			return theOrange;
		}
		else if(numBoule == 2) {
			return Color.BLUE;
		}
		else if(numBoule == 3) {
			return Color.CYAN;
		}
		else if(numBoule == 4) {
			return colorPurple;
		}
		else if(numBoule == 5) {
			return Color.green;
		}
		else if(numBoule == 6) {
			return Color.magenta;
		}
		else if(numBoule == 7) {
			return Color.ORANGE;
		}
		else if(numBoule == 8) {
			return Color.pink;
		}
		else if(numBoule == 9) {
			return Color.RED;
		}
		else if(numBoule == 10) {
			return Color.YELLOW;
		}
		else if(numBoule == 11) {
			return Color.white;
		}
		else {
			return darkBlue;
		}
	}
	
	
}
