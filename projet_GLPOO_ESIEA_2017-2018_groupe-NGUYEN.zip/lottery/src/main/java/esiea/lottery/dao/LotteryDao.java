package esiea.lottery.dao;

import java.io.File;
import java.util.List;

import esiea.lottery.domain.Lottery;

public interface LotteryDao {

	List<Lottery> findAllTirage() throws Exception;

	void init(File file);
}
