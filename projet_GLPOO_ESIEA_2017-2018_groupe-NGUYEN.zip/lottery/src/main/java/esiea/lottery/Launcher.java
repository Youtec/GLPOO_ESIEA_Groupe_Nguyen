package esiea.lottery;

import javax.swing.SwingUtilities;

import org.apache.log4j.Logger;

import esiea.lottery.ihm.Frame;
import esiea.lottery.ihm.ResultTable;


public class Launcher {
	
	private final static Logger logger = Logger.getLogger(Launcher.class);
	
	public static void main(String[] args) {
		logger.debug("Launching program");
		logger.debug("Initialize csv file");
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {

				try {
					logger.debug("Running frame");
					new Frame();

					logger.debug("Running Euromillion result");
					final ResultTable fenetre = new ResultTable();
					fenetre.setVisible(true);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				// new Frame();
			}
		});

	}

}
