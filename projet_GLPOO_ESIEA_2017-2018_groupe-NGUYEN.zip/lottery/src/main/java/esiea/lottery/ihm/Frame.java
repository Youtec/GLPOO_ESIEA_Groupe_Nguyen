package esiea.lottery.ihm;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Frame extends JFrame {

	private JMenuBar menu_bar = new JMenuBar();
	private JMenu menu_option_1 = new JMenu("Fichier");
	private JMenu menu_option_2 = new JMenu("Aide");
	private JMenu menu_option_3 = new JMenu("Informations");
	private JMenuItem menu_1_sauver = new JMenuItem("Enregistrer le fichier");
	private JMenuItem menu_1_charger = new JMenuItem("Charger le fichier");
	private JMenuItem menu_1_supprimer = new JMenuItem("Effacer les donn�es");
	private JMenuItem menu_1_size = new JMenuItem("Elargir les r�sultats");

	private static final long serialVersionUID = 1L;

	public Frame() throws Exception {
		super();
		propertiesFrame();
	}

	private void propertiesFrame() throws Exception {
		/*
		 * --------------------------------------------------- Propri�t�s de la fen�tre
		 * ---------------------------------------------------
		 */
		this.setTitle("Projet GLPOO");
		this.setSize(1920, 1200);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		this.setBackground(Color.LIGHT_GRAY);

		Panel_IHM panel_IHM = new Panel_IHM();
		panel_IHM.setOpaque(true);
		this.setContentPane(panel_IHM);

		/*
		 * --------------------------------------------------- Menu du logiciel
		 * ---------------------------------------------------
		 */

		menu_bar.add(menu_option_1);
		menu_bar.add(menu_option_2);
		menu_bar.add(menu_option_3);

		menu_option_1.add(menu_1_sauver);
		menu_option_1.add(menu_1_charger);
		menu_option_1.add(menu_1_supprimer);
		menu_option_1.add(menu_1_size);

		setJMenuBar(menu_bar);

		// �v�nement pour la barre de t�che
		menu_1_sauver.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

			}
		});

		menu_option_3.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

			}
		});
	}
}
