package esiea.lottery.ihm;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.io.File;
import java.util.List;
import java.util.Random;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;

import org.apache.log4j.Logger;

import esiea.lottery.Launcher;
import esiea.lottery.dao.CsvLotteryDao;
import esiea.lottery.dao.LotteryDao;
import esiea.lottery.domain.Lottery;
import esiea.graphism.Square;

public class LotteryTable extends JPanel {
	
	 JTable jt;
     private List<Lottery> tirages;
     private String[] headers;
     Square theSquare = new Square();
     JScrollPane jps;
     Object[][] data = new Object[15][15];

     public LotteryTable(int choix) throws Exception
     {
    	 
    	 Random r = new Random();
 		// variable al�atoire qui choisi entre les 142 tirages
 		headers = new String[] { "Annee et Numero du Tirage", "Jour", "Date", "Numero du tirage dans le cycle",
 				"Date de fermeture", "Boule1", "Boule 2", "Boule 3", "Boule 4", "Boule 5", "Etoile 1", "Etoile 2" };

 		final String fileName = "src/main/resources/my_euromillions.csv";
 		final File file = new File(fileName);
 		final LotteryDao dao = new CsvLotteryDao();
 		dao.init(file);
 		tirages = dao.findAllTirage();
 
 		
 		for(int x = 0; x<15; x++) {
	 		int i = 1 + r.nextInt(142 - 1);
	 		data[x][0] =  tirages.get(i).getBoule1();
	 		data[x][1] = tirages.get(i).getBoule2();
	 		data[x][2] = tirages.get(i).getBoule3();
	 		data[x][3] = tirages.get(i).getBoule4();
	 		data[x][4] = tirages.get(i).getBoule5();
	 		data[x][5] = tirages.get(i).getEtoile1();
	 		data[x][6] = tirages.get(i).getEtoile2();
 		}
 		
 		
 		
          // Columns for table
          String[] columns = {"Boule1", "Boule2", "Boule3", "Boule4", "Boule5","Etoile1","Etoile2"};
          
          // 2D array is used for data in table
         //Object[][] data = getData(choix);
          
          theSquare.getPrint(choix, data);
          
  
          // Creates Table
          if(jt == null) {
          jt = new JTable(data, columns)
          {
               // Determines if data can be entered by users
               public boolean isCellEditable(int data, int columns)
               {
                   return false;
               }
   
               //  Creates cells for the table         
               public Component prepareRenderer(
                            TableCellRenderer r, int data, int columns)
               {
                   Component c = super.prepareRenderer(r, data, columns);
                  
                   // Every even numbers
                   if (data % 2 == 0)
                       c.setBackground(Color.WHITE);
    
                   else
                       c.setBackground(Color.LIGHT_GRAY);
    
                   return c;
               }
         };
          }
  
         // Set size of table     
         jt.setPreferredScrollableViewportSize(new Dimension(450, 130));

         // This will resize the height of the table automatically 
         // to all data without scrolling. 
         jt.setFillsViewportHeight(true);

         jps = new JScrollPane(jt);
         add(jps);
     }
     
     
     public void getTirage(int choix) throws Exception {
    	 Random r = new Random();
 		
 		headers = new String[] { "Annee et Numero du Tirage", "Jour", "Date", "Numero du tirage dans le cycle",
 				"Date de fermeture", "Boule1", "Boule 2", "Boule 3", "Boule 4", "Boule 5", "Etoile 1", "Etoile 2" };

 		final String fileName = "src/main/resources/my_euromillions.csv";
 		final File file = new File(fileName);
 		final LotteryDao dao = new CsvLotteryDao();
 		dao.init(file);
 		tirages = dao.findAllTirage();
 		for(int x = 0; x<15; x++) {
	 	
	 		data[x][0] = " ";
	 		data[x][1] = " ";
	 		data[x][2] = " ";
	 		data[x][3] = " ";
	 		data[x][4] = " ";
	 		data[x][5] = " ";
	 		data[x][6] = " ";
 		}
 		for(int x = 0; x<choix; x++) {
	 		int i = 1 + r.nextInt(142 - 1);
	 		data[x][0] =  tirages.get(i).getBoule1();
	 		data[x][1] = tirages.get(i).getBoule2();
	 		data[x][2] = tirages.get(i).getBoule3();
	 		data[x][3] = tirages.get(i).getBoule4();
	 		data[x][4] = tirages.get(i).getBoule5();
	 		data[x][5] = tirages.get(i).getEtoile1();
	 		data[x][6] = tirages.get(i).getEtoile2();
 		}
          // Columns for table
          String[] columns = {"Boule1", "Boule2", "Boule3", "Boule4", "Boule5","Etoile1","Etoile2"};
          

          
          theSquare.getPrint(choix, data);
          
          ((AbstractTableModel)jt.getModel()).fireTableDataChanged();	
          ((AbstractTableModel)jt.getModel()).fireTableStructureChanged();	
          jps.revalidate();

     }

	// Creates Window
}