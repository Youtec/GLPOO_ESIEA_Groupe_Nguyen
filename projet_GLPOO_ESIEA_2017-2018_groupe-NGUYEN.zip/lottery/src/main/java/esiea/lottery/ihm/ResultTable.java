package esiea.lottery.ihm;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import org.apache.log4j.Logger;

import esiea.lottery.Launcher;


public class ResultTable extends JFrame {
	private static final long serialVersionUID = 1L;
	private final static Logger log = Logger.getLogger(Launcher.class);
	private final TableModel modele = new TableModel();
	private final JTable tableau = new JTable(modele);

	public ResultTable() throws Exception {
		log.debug("CSV DATA");
		setTitle("Lottery");
		setPreferredSize(new Dimension(1920, 1080));
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		final JPanel scrollButton = new JPanel();

		final JScrollPane scroll = new JScrollPane(tableau);
		getContentPane().add(scroll, BorderLayout.CENTER);
		getContentPane().add(scrollButton, BorderLayout.SOUTH);
		tableau.setAutoCreateRowSorter(true);

		pack();
	}

}
