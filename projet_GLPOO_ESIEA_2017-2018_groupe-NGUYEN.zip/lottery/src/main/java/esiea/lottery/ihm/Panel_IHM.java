package esiea.lottery.ihm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

import org.apache.log4j.Logger;

import esiea.graphism.*;
import esiea.lottery.Launcher;

public class Panel_IHM extends JPanel {
	
	private final static Logger logger = Logger.getLogger(Launcher.class);

public Panel_IHM() throws Exception {
		
		super();
		this.propertiesIHM();
		Square theSquare = new Square();
		
		
	}
	
	private JLabel Titre = new JLabel("EURODROO");
	private JLabel photo = new JLabel ();
	private JLabel loto = new JLabel ();
	private JLabel loto2 = new JLabel ();
	private Font font_titre = new Font("Broadway", Font.BOLD, 40);
	private ImageIcon logo_esiea = new ImageIcon("Ressources/logo esiea.jpg");
	private ImageIcon logo_loto = new ImageIcon("Ressources/loto.jpg");
	private ImageIcon logo_loto2 = new ImageIcon("Ressources/loto2.png");
	
	
	private JPanel panel = new JPanel();
	private JLabel tirage = new JLabel("Veuillez choisir le nombre et date pour lancer la simulation");
	private JLabel nombre_tirage = new JLabel("Quantit� :");
	private JLabel date_tirage = new JLabel("Date :");
	private JLabel sauvegarder = new JLabel("Sauvegarder :");
	private JLabel saveInfo = new JLabel("Si vous souhaitez les sauvegarder");
	private JLabel saveInfo2 = new JLabel("vos images seront stock�es dans le dossier PicturesSaved");
    private JTextField nom_save = new JTextField("Nom de l'enregistrement");

	private Integer[] valeur_select = {1,2,3,4,5,10,15};
	private JButton button = new JButton("Lancer une simulation");
	private JComboBox<Integer> select = new JComboBox<>(valeur_select);
	private JTextField date = new JTextField();
	private ImageIcon logo_save = new ImageIcon("Ressources/save.png");
	private JButton Save = new JButton(logo_save);
	private ImageIcon logo_delete = new ImageIcon("Ressources/Delete.png");
	private JButton Delete = new JButton(logo_delete);
	private ImageIcon logo_dice = new ImageIcon("Ressources/Dice.png");
	private JButton Dice = new JButton(logo_dice);
	private JInternalFrame iFrame = new JInternalFrame();
    private JLabel label;
    
    JInternalFrame jf = new JInternalFrame("Tutorial");
    
    Square theSquare = new Square();
    LotteryTable t = new LotteryTable(1);
	
	
	
	
	public int frameNbr = 0; //Nombre de Dessins g�n�r�s
	public String filepath; 
	
	

	String[] titre_colonnes = 
		{ "Boule1", "Boule2", "Boule3", "Boule4", "Boule5","Etoile2","Etoile1"};
	Object[][] donnees = {
			{ "1", "2", "3", "4" , "5", "6","7" }, 
			{ "1", "2", "3", "4" , "5", "6","7" }, 
	};
	
	final JTable table = new JTable(donnees,titre_colonnes);
	private boolean DEBUG = false;
	JScrollPane scrollPane = new JScrollPane(table);
	

	
	private static final long serialVersionUID = 1L;
	
	
		
	private void propertiesIHM(){
		/* ---------------------------------------------------
		 * Partie 1 : Affichage g�n�ral
		 ---------------------------------------------------*/
		
	   jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    jf.add(t);
        jf.pack();   
		jf.setResizable(false);
		jf.setBounds(50,520,500,200);
		jf.setTitle("Tirage");
		add(jf); 
        jf.setVisible(true);
		
		this.setLayout(null);
		photo.setIcon(logo_esiea);
		loto.setIcon(logo_loto);
		loto2.setIcon(logo_loto2);
		Titre.setFont(font_titre);
		
		Titre.setForeground(Color.DARK_GRAY);
		Titre.setBounds(800,20,400,30);
		photo.setBounds(1100, 5, 200, 103);
		loto.setBounds(150, 820, 300, 100);
		loto2.setBounds(450, 60, 350,350);
		
	 
		add(Titre);
		add(photo);
		add(loto);
		add(loto2);
		
		
		/* ---------------------------------------------------
		 * Partie 2 : Composants de dialogue avec l'utilisateur
		 ---------------------------------------------------*/
		panel.setLayout(null);
		date.setText("dd/mm/yy");
		 
		Border border=BorderFactory.createTitledBorder("Choix pour le Tirage");
		panel.setBorder(border);
		
		// Positionnement des �l�ments dans le panneau
		tirage.setBounds(30, 50, 450, 20);
		nombre_tirage.setBounds(30, 110, 100, 20);
		select.setBounds(160, 110, 50, 25);
		date_tirage.setBounds(30, 170, 100, 20);
		sauvegarder.setBounds(10, 220, 100, 20);
		saveInfo.setBounds(30, 255, 400, 20);
		saveInfo2.setBounds(30, 270, 400, 20);
		date.setBounds(130,170,80,20);
		nom_save.setBounds(100,220,200,20);
		//nom_save.setPreferredSize(new Dimension(150, 30));
		button.setBounds(160, 380, 200, 50);
		Delete.setBounds(10,380,50,50);
		Save.setBounds(315,210,50,50);
		Dice.setBounds(80,380,50,50);
		panel.setBounds(50,80,400,450);
		
		
		
		// Ajout dans le panneau des �l�ments
		panel.add(button);
		panel.add(select);
		panel.add(tirage);
		panel.add(nombre_tirage);
		panel.add(date_tirage);
		panel.add(sauvegarder);
		panel.add(saveInfo);
		panel.add(saveInfo2);
		panel.add(nom_save);
		panel.add(date);
		panel.add(Delete);
		panel.add(Save);
		panel.add(Dice);
		add(panel);
	
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                label = new JLabel();
                label.setHorizontalAlignment(JLabel.CENTER);
                label.setVerticalAlignment(JLabel.CENTER);
                iFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                iFrame.setLayout(new BorderLayout());
                iFrame.add(label);
                button.doClick();
                iFrame.pack();
              
        		iFrame.setResizable(false);
        		iFrame.setBounds(720,130,610,560);
        		iFrame.setTitle("Dessin");
        		add(iFrame); 
                
                iFrame.setVisible(true);
            }
        });
		
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logger.debug("Another simulation");
				//ShowLabelImage();
				int choix = getChoix(select.getSelectedIndex());
				try {
					t.getTirage(choix);
					jf.add(t);
				        
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				filepath = "PicBin/test"+(frameNbr+1)+".png";
				File deleteFile = new File("PicBin/test"+(frameNbr)+".png");
				deleteFile.delete();
            	
                label.setIcon(new ImageIcon(filepath));
                frameNbr++;
			}
		});
		
		
		Delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				model.setRowCount(0);
			}
		});
		
		Save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logger.debug("Picture saved");
				int picNbr = frameNbr;
				picNbr--;
				String theSaveName = nom_save.getText();
				String picName = "PicBin/test" + (picNbr+1) +".png";
				String newName = "PicturesSaved/"+theSaveName+".png";
				File myFile = new File(picName);
				myFile.renameTo(new File(newName));
			}
		});

		
		/* ---------------------------------------------------
		 * Partie 4 : Tableau des tirages 
		 ---------------------------------------------------*/
		
		scrollPane.setBounds(50, 600, 500, 320);
		table.setPreferredScrollableViewportSize(new Dimension(500, 320));
	    table.setFillsViewportHeight(true);
	    table.setAutoCreateRowSorter(true);
	   
	    if (DEBUG) {
            table.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    printDebugData(table);
                }
            });
	    }
	    
	    add(scrollPane);
         
	}	
	
	/* ---------------------------------------------------
	 * Partie 3 : Affichage du r�sultat / dessin
	 ---------------------------------------------------*/

		public int getChoix(int choix) {
			int theChoix = 0;
			
			switch(choix) {
			case 0:
				theChoix = 1;
				break;
			case 1:
				theChoix = 2;
				break;
			case 2:
				theChoix = 3;
				break;
			case 3:
				theChoix = 4;
				break;
			case 4:
				theChoix = 5;
				break;
			case 5:
				theChoix = 10;
				break;
			case 6:
				theChoix = 15;
				break;
			}
			return theChoix;
		}
	
	    private void printDebugData(JTable table) {
	        int numRows = table.getRowCount();
	        int numCols = table.getColumnCount();
	        javax.swing.table.TableModel model = table.getModel();
	 
	        System.out.println("Value of data: ");
	        for (int i=0; i < numRows; i++) {
	            System.out.print("    row " + i + ":");
	            for (int j=0; j < numCols; j++) {
	                System.out.print("  " + model.getValueAt(i, j));
	            }
	            System.out.println();
	        }
	        System.out.println("--------------------------");
	    }
}
