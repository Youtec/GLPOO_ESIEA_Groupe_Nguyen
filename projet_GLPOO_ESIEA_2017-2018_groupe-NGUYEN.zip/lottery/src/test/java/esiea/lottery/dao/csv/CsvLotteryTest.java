package esiea.lottery.dao.csv;

import java.io.File;

import org.junit.Before;

import esiea.lottery.dao.CsvLotteryDao;

public class CsvLotteryTest extends AbstractLotteryDaoTest {

	private final static String RESOURCES_PATH = "src/test/resources/";
	private final static String TIRAGES_FILE_PATH = "test_euromillions.csv";
	
	@Before
	public void doBefore() {
		final File file = new File(RESOURCES_PATH + TIRAGES_FILE_PATH);
		dao = new CsvLotteryDao();
		dao.init(file);
	}
	
}
