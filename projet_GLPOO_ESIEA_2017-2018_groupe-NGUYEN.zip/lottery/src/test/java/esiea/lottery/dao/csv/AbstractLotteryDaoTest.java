package esiea.lottery.dao.csv;


import java.util.List;


import org.junit.Test;

import esiea.lottery.dao.LotteryDao;
import esiea.lottery.domain.Lottery;

import org.junit.Assert;

public abstract class AbstractLotteryDaoTest {

	protected LotteryDao dao;

	@Test
	public void testAnnee() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final int expected = 2016078;// first draw
		final int expected2 = 2016083;//sixth draw
		final int expected3 = 2018010;//last draw
		
		final int annee = tirages.get(0).getAnnee();
		final int annee2 = tirages.get(5).getAnnee();
		final int annee3 = tirages.get(141).getAnnee();
		Assert.assertEquals(expected, annee);
		Assert.assertEquals(expected2, annee2);
		Assert.assertEquals(expected3, annee3);
	}

	@Test
	public void testDay() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final String expected = "MARDI";
		final String expected2 = "VENDREDI";
		final String expected3 = "VENDREDI";
		
		final String day = tirages.get(0).getJour();
		final String day2 = tirages.get(5).getJour();
		final String day3 = tirages.get(141).getJour();
		Assert.assertEquals(expected, day);
		Assert.assertEquals(expected2, day2);
		Assert.assertEquals(expected3, day3);
	}

	@Test
	public void testDate() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final String[] expected = { "27", "09", "2016" };
		final String[] expected2 = { "14", "10", "2016" };
		final String[] expected3 = { "02", "02", "2018" };
		final String[] tableDate = tirages.get(0).getDate();
		final String[] tableDate2 = tirages.get(5).getDate();
		final String[] tableDate3 = tirages.get(141).getDate();
		Assert.assertArrayEquals(expected, tableDate);
		Assert.assertArrayEquals(expected2, tableDate2);
		Assert.assertArrayEquals(expected3, tableDate3);
	}

	@Test
	public void testEndDate() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final String[] expected = { "27", "11", "2016" };
		final String[] expected2 = { "14", "12", "2016" };
		final String[] expected3 = { "04", "04", "2018" };
		final String[] tableEndDate = tirages.get(0).getDateFermeture();
		final String[] tableEndDate2 = tirages.get(5).getDateFermeture();
		final String[] tableEndDate3 = tirages.get(141).getDateFermeture();
		Assert.assertArrayEquals(expected, tableEndDate);
		Assert.assertArrayEquals(expected2, tableEndDate2);
		Assert.assertArrayEquals(expected3, tableEndDate3);
	}

	@Test
	public void testNumTirage() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final int expected = 1;
		final int expected2 = 2;
		final int expected3 = 11;
		final int numero = tirages.get(0).getNumeroTirage();
		final int numero2 = tirages.get(5).getNumeroTirage();
		final int numero3 = tirages.get(141).getNumeroTirage();
		Assert.assertEquals(expected, numero);
		Assert.assertEquals(expected2, numero2);
		Assert.assertEquals(expected3, numero3);
	}

	@Test
	public void testBoule1() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final int expected = 41;
		final int expected2 = 31;
		final int expected3 = 36;
		final int boule = tirages.get(0).getBoule1();
		final int boule2 = tirages.get(5).getBoule1();
		final int boule3 = tirages.get(141).getBoule1();
		Assert.assertEquals(expected, boule);
		Assert.assertEquals(expected2, boule2);
		Assert.assertEquals(expected3, boule3);
	}

	@Test
	public void testBoule2() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final int expected = 6;
		final int expected2 = 34;
		final int expected3 = 39;
		final int boule = tirages.get(0).getBoule2();
		final int boule2 = tirages.get(5).getBoule2();
		final int boule3 = tirages.get(141).getBoule2();
		Assert.assertEquals(expected, boule);
		Assert.assertEquals(expected2, boule2);
		Assert.assertEquals(expected3, boule3);
	}

	@Test
	public void testBoule3() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final int expected = 13;
		final int expected2 = 19;
		final int expected3 = 34;
		final int boule = tirages.get(0).getBoule3();
		final int boule2 = tirages.get(5).getBoule3();
		final int boule3 = tirages.get(141).getBoule3();
		Assert.assertEquals(expected, boule);
		Assert.assertEquals(expected2, boule2);
		Assert.assertEquals(expected3, boule3);
	}

	@Test
	public void testBoule4() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final int expected = 39;
		final int expected2 = 7;
		final int expected3 = 14;
		final int boule = tirages.get(0).getBoule4();
		final int boule2 = tirages.get(5).getBoule4();
		final int boule3 = tirages.get(141).getBoule4();
		Assert.assertEquals(expected, boule);
		Assert.assertEquals(expected2, boule2);
		Assert.assertEquals(expected3, boule3);
	}

	@Test
	public void testBoule5() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final int expected = 9;
		final int expected2 = 13;
		final int expected3 = 48;
		final int boule = tirages.get(0).getBoule5();
		final int boule2 = tirages.get(5).getBoule5();
		final int boule3 = tirages.get(141).getBoule5();
		Assert.assertEquals(expected, boule);
		Assert.assertEquals(expected2, boule2);
		Assert.assertEquals(expected3, boule3);
	}

	@Test
	public void testEtoile1() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final int expected = 2;
		final int expected2 = 11;
		final int expected3 = 2;
		final int etoile = tirages.get(0).getEtoile1();
		final int etoile2 = tirages.get(5).getEtoile1();
		final int etoile3 = tirages.get(141).getEtoile1();
		Assert.assertEquals(expected, etoile);
		Assert.assertEquals(expected2, etoile2);
		Assert.assertEquals(expected3, etoile3);
	}

	@Test
	public void testEtoile2() throws Exception {
		final List<Lottery> tirages = dao.findAllTirage();
		final int expected = 12;
		final int expected2 = 1;
		final int expected3 = 3;
		final int etoile = tirages.get(0).getEtoile2();
		final int etoile2 = tirages.get(5).getEtoile2();
		final int etoile3 = tirages.get(141).getEtoile2();
		Assert.assertEquals(expected, etoile);
		Assert.assertEquals(expected2, etoile2);
		Assert.assertEquals(expected3, etoile3);
	}

}
